"""E3: Random Waypoint / unit-disk graph (RWP/UDG) networks.
Methods: certificate flooding, precomputed flooding, uncertified max-consensus and linear consensus.
Adversaries: state-aware blackout targeted at the method (t0 = 0), budget-saving variant (t0 = sigma*),
oblivious random blackout, and the instance-level cut-covering adversary of Theorem 6 (isolates one robot).
Also: finite-horizon coverability of all singleton cuts (Theorem 6), density estimates (Theorem 5),
dissemination completion times of precomputed flooding, and diagnostics at sigma*."""
import json, math, random, statistics as st, sys
from scgd_dos import *

def q(v):
    v = sorted(v); n = len(v)
    return v[n // 4], st.median(v), v[(3 * n) // 4], v[-1]

def main(n=30, M=500, r=0.25, H=6000, TR=20, mode="planted", tag="e3", methods=None, scen_keep=None):
    methods = methods or [CertFlood, PreFlood, MaxCons, LinCons]
    res, info = {}, []
    for tr in range(TR):
        rng = random.Random(500 + tr)
        sch = RWPUDC(n, r, H, rng)
        W = joint_connectivity_window(sch, n, H - 400)
        conn = [1.0 if connected(n, sch.intended(t)) else 0.0 for t in range(H)]
        frac = sum(conn) / H
        rho = 0.9 * frac
        beta = density_lower(conn, rho)
        if mode == "equal":
            s0 = [argmax_sigma(M)] * n
        elif mode == "small":
            s0 = [rng.randint(1, M) for _ in range(n)]
        else:
            s0 = initial_states(n, M, rng)
        sig = max(sigma(v) for v in s0)
        vstar = max(range(n), key=lambda i: sigma(s0[i]))
        attackable = [bool(sch.intended(t)) for t in range(H)]
        cross = [[any(i in e for e in sch.intended(t)) for t in range(H)] for i in range(n)]
        dens_single = [sum(c) / H for c in cross]
        vsparse = min(range(n), key=lambda i: dens_single[i])
        scen = {"none": (0, math.inf, 1, None), "B": (1, 2.0, W + 1, "thm2b"),
                "D": (5, 1.0 / (0.9 * rho), 1, "thm5"), "H": (5, 1.25, 1, None)}
        if scen_keep:
            scen = {k: v for k, v in scen.items() if k in scen_keep}
        cov = {}
        for sname in ("D", "H"):
            if sname not in scen:
                continue
            kappa, tD, tF, _ = scen[sname]
            cov[sname] = dict(
                from0=sum(coverable(cross[i], attackable, 0, H, kappa, tD, tF) for i in range(n)),
                from_sigma=sum(coverable(cross[i], attackable, sigma(s0[i]), H, kappa, tD, tF) for i in range(n)))
        info.append(dict(W=W, frac=frac, rho=rho, beta=beta, sig=sig, tauD_D=1.0 / (0.9 * rho),
                         min_single_density=min(dens_single), cov=cov))
        for sname, (kappa, tD, tF, thm) in scen.items():
            if thm == "thm2b":
                L = math.floor(ell_max(kappa, tD) + 1e-12)
                bnd = sig + (n - 1) * (2 * W - 1 + L)
            elif thm == "thm5":
                bnd = T_bound_density(sig, n, rho, beta, kappa, tD)
            elif sname == "none":
                bnd = sig + (n - 1) * W
            else:
                bnd = None
            if sname == "none":
                advs = {"none": lambda m: ObliviousWrap(NoAttack())}
            else:
                advs = {"targeted": lambda m: TargetedBlackout(0),
                        "random": lambda m: ObliviousWrap(RandomBlackout(0.5, random.Random(tr)))}
                if sname in ("D", "H"):
                    advs["budget-saving"] = lambda m: TargetedBlackout(sig)
                    advs["cut-cover"] = lambda m: (CutCover(vstar, sig) if m is CertFlood else CutCover(vsparse, 0))
            for mcls in methods:
                for aname, mk in advs.items():
                    if aname in ("budget-saving", "cut-cover") and mcls not in (CertFlood, PreFlood):
                        continue
                    proto = mcls(n, s0)
                    probe = sig if (mcls is CertFlood and aname in ("targeted", "budget-saving")) else None
                    T, atk, pr = run_protocol(sch, n, proto, mk(mcls), Budget(kappa, tD, tF), H, probe_t=probe)
                    key = (sname, mcls.name, aname)
                    R = res.setdefault(key, dict(T=[], frac=[], bnd=[], ok=[], diss=[], probe=[]))
                    R["T"].append(T)
                    R["frac"].append(sum(1 for a in atk if T is None or a < T) / (T or H))
                    if isinstance(proto, PreFlood):
                        R["diss"].append(proto.diss)
                    if pr:
                        R["probe"].append(pr)
                    if bnd is not None and mcls is CertFlood:
                        R["bnd"].append(bnd); R["ok"].append(T is not None and T <= bnd)
        print(tr, W, round(frac, 3), round(beta, 1), sig, cov, flush=True)
    out = []
    for (sname, mname, aname), R in res.items():
        base = res[("none", mname, "none")]["T"]
        Ts = R["T"]
        conv = [t for t in Ts if t is not None]
        inc = [t - b for t, b in zip(Ts, base) if t is not None and b is not None]
        row = dict(scenario=sname, method=mname, adversary=aname, conv=len(conv), trials=len(Ts),
                   T_q=q(conv) if conv else None, inc_q=q(inc) if inc else None,
                   frac_med=st.median(R["frac"]),
                   bound_med=st.median(R["bnd"]) if R["bnd"] else None,
                   bound_holds=all(R["ok"]) if R["ok"] else None)
        if R["diss"]:
            d = [x for x in R["diss"] if x is not None]
            row["diss_q"] = q(d) if d else None
            row["diss_done"] = len(d)
        if R["probe"]:
            row["probe_g_med"] = st.median(p["g"] for p in R["probe"])
            row["probe_incomplete_med"] = st.median(p.get("incomplete", 0) for p in R["probe"])
            row["probe_burst_med"] = st.median(p["burst"] for p in R["probe"])
        if mname == CertFlood.name:
            sigs = [i["sig"] for i in info]
            ov = [t - s for t, s in zip(Ts, sigs) if t is not None]
            row["overhead_q"] = q(ov) if ov else None
        out.append(row); print(row)
    summ = dict(W=q([i["W"] for i in info]), frac=q([i["frac"] for i in info]),
                beta=q([i["beta"] for i in info]), tauD_D=q([i["tauD_D"] for i in info]),
                min_single_density=q([i["min_single_density"] for i in info]))
    print(summ)
    json.dump(dict(rows=out, info=info, summary=summ), open(f"{tag}.json", "w"), indent=1, default=str)

if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if arg == "equal":
        main(mode="equal", tag="e3_equal", methods=[CertFlood, PreFlood], scen_keep=("none", "H"))
    elif arg == "small":
        main(M=10, mode="small", tag="e3_small", methods=[CertFlood, PreFlood], scen_keep=("none", "D", "H"))
    elif arg == "nsweep":
        for nn in (15, 30, 60):
            main(n=nn, tag=f"e5_n{nn}", methods=[CertFlood, PreFlood], scen_keep=("none", "H"))
    else:
        main()
