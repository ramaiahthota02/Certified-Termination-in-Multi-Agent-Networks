"""Reference simulator for

    H. R. Vidyashree, G. Thota, N. Vadlana, and R. Kumar,
    "Certified Termination in Multi-Agent Networks Under Denial-of-Service Attacks,"
    submitted to the IEEE Open Journal of Control Systems.

Implements
  * the value layer and its completion times (S-CGD Collatz update, topology independent),
  * token flooding (Definition 1): certificate flooding (release at completion) and precomputed
    flooding (release at start-up), with the token sets K_t(i) as bitmasks,
  * the duration budget (kappa, tau_D) of Definition 4 and the frequency budget (eta, tau_F) of
    Definition 5, enforced online by the equivalent recursions of Section VI-A; only effective
    attack rounds (Definition 3) are charged,
  * intended schedules: the bridge path of Theorem 3, a round-robin path, and Random Waypoint
    mobility with unit-disk communication,
  * adversaries: bridge-blocking, periodic blackout (phase searched), random blackout, state-aware
    targeted blackout, its budget-saving variant, and the cut-covering adversary of Theorem 6,
  * the bounds of Theorem 2 and Theorem 5, the characterization test of Theorem 4, and the
    coverability recursion of Definition 6 and Remark 9,
  * baselines replayed on the identical attacked edge sequence: max-consensus and linear consensus.

Python 3 with numpy; matplotlib is needed only by figs.py. All random seeds are fixed.
"""
import math
import random
from functools import lru_cache

import numpy as np


# ========================================================== Collatz
def collatz(n):
    return n // 2 if n % 2 == 0 else 3 * n + 1


@lru_cache(maxsize=None)
def sigma(n):
    """Total stopping time: number of Collatz steps to reach 1."""
    c = 0
    while n != 1:
        n = collatz(n)
        c += 1
    return c


def sigma_max(M):
    return max(sigma(m) for m in range(1, M + 1))


def argmax_sigma(M):
    return max(range(1, M + 1), key=sigma)


# ========================================================== DoS budget
class Budget:
    """Online checker for the duration budget (kappa, tau_D) and the frequency budget
    (eta, tau_F), charging only effective attack rounds (Definition 2).

    g_t = max_{t1<=t} [ #attack rounds in [t1,t] - (t-t1)/tau_D ] obeys
          g_t = a_t + max(0, g_{t-1} - 1/tau_D), g_{-1} = 0; the duration budget <=> g_t <= kappa.
    h_t = max_{t1<=t} [ #onsets in [t1,t] - (t-t1)/tau_F ] obeys
          h_t = o_t + max(0, h_{t-1} - 1/tau_F), h_{-1} = 0; the frequency budget <=> h_t <= eta.
    For eta = 1 the frequency budget is equivalent to consecutive onsets >= tau_F apart.
    """

    def __init__(self, kappa, tau_D, tau_F, eta=1.0):
        self.kappa, self.eta = kappa, eta
        self.inv = 0.0 if (tau_D is None or math.isinf(tau_D)) else 1.0 / tau_D
        self.invF = 0.0 if (tau_F is None or math.isinf(tau_F)) else 1.0 / tau_F
        self.tau_F = tau_F
        self.g = 0.0
        self.h = 0.0
        self.prev_attack = False
        self.n_attack = 0
        self.onsets = 0

    def can_attack(self, t):
        if 1.0 + max(0.0, self.g - self.inv) > self.kappa + 1e-9:
            return False
        if not self.prev_attack and 1.0 + max(0.0, self.h - self.invF) > self.eta + 1e-9:
            return False
        return True

    def commit(self, t, attacked):
        onset = attacked and not self.prev_attack
        self.g = (1.0 if attacked else 0.0) + max(0.0, self.g - self.inv)
        self.h = (1.0 if onset else 0.0) + max(0.0, self.h - self.invF)
        if attacked:
            self.n_attack += 1
        if onset:
            self.onsets += 1
        self.prev_attack = attacked


def ell_max(kappa, tau_D):
    """Lemma 1: maximal attack-interval length (kappa*tau_D - 1)/(tau_D - 1)."""
    if math.isinf(tau_D):
        return float(kappa)
    return (kappa * tau_D - 1.0) / (tau_D - 1.0)


# ========================================================== schedules
class BridgePath:
    """Necessity construction: path P_n; bridge e* on for L rounds, off for W-1 rounds
    (period W+L-1); every other path edge on once per W rounds at a random phase."""

    def __init__(self, n, W, L, rng):
        self.n, self.W, self.L = n, W, L
        self.edges = [(i, i + 1) for i in range(n - 1)]
        self.bridge = self.edges[(n - 1) // 2]
        self.P = W + L - 1
        self.bphase = 0  # first bridge cluster starts at t = 0 (aligned construction)
        self.phase = {e: rng.randrange(W) for e in self.edges if e != self.bridge}

    def bridge_on(self, t):
        return (t - self.bphase) % self.P < self.L

    def intended(self, t):
        E = [e for e, p in self.phase.items() if t % self.W == p]
        if self.bridge_on(t):
            E.append(self.bridge)
        return E


class RoundRobinPath:
    """Path P_n; every edge on exactly once per W rounds at a random phase."""

    def __init__(self, n, W, rng):
        self.n, self.W = n, W
        self.edges = [(i, i + 1) for i in range(n - 1)]
        self.bridge = self.edges[(n - 1) // 2]
        self.phase = {e: rng.randrange(W) for e in self.edges}

    def intended(self, t):
        return [e for e, p in self.phase.items() if t % self.W == p]


class RWPUDC:
    """Random Waypoint mobility in the unit square with Unit Disk Communication radius r."""

    def __init__(self, n, r, horizon, rng, vmin=0.005, vmax=0.02):
        self.n, self.r = n, r
        pos = np.array([[rng.random(), rng.random()] for _ in range(n)])
        tgt = np.array([[rng.random(), rng.random()] for _ in range(n)])
        spd = np.array([rng.uniform(vmin, vmax) for _ in range(n)])
        self.E = []
        iu = np.triu_indices(n, 1)
        for _ in range(horizon):
            d = np.sqrt(((pos[:, None, :] - pos[None, :, :]) ** 2).sum(-1))
            mask = d[iu] <= r
            self.E.append([(int(a), int(b)) for a, b, m in zip(iu[0], iu[1], mask) if m])
            step = tgt - pos
            dist = np.linalg.norm(step, axis=1)
            arrive = dist <= spd
            pos = np.where(arrive[:, None], tgt, pos + step * (spd / np.maximum(dist, 1e-12))[:, None])
            for i in np.where(arrive)[0]:
                tgt[i] = [rng.random(), rng.random()]
                spd[i] = rng.uniform(vmin, vmax)

    def intended(self, t):
        return self.E[t]


def connected(n, E):
    parent = list(range(n))

    def f(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    comps = n
    for a, b in E:
        ra, rb = f(a), f(b)
        if ra != rb:
            parent[ra] = rb
            comps -= 1
    return comps == 1


def joint_connectivity_window(sched, n, horizon):
    """Smallest W such that every length-W window of the intended schedule (within the
    horizon) has a connected union."""
    Wmax = 1
    for k in range(horizon):
        U = set()
        w = 0
        while k + w < horizon:
            U.update(sched.intended(k + w))
            w += 1
            if connected(n, U):
                break
        else:
            break
        Wmax = max(Wmax, w)
    return Wmax


# ========================================================== adversaries
class NoAttack:
    def decide(self, t, Estar, K, budget):
        return set()


class BridgeBlocker:
    """Schedule-aware, state-oblivious: removes the bridge whenever it is scheduled and the
    budget allows."""

    def __init__(self, bridge):
        self.bridge = bridge

    def decide(self, t, Estar, K, budget):
        if self.bridge in Estar and budget.can_attack(t):
            return {self.bridge}
        return set()


class PeriodicBlackout:
    """Full blackout on rounds with (t - phase) mod P < b (subject to the budget)."""

    def __init__(self, P, b, phase):
        self.P, self.b, self.phase = P, b, phase

    def decide(self, t, Estar, K, budget):
        if Estar and (t - self.phase) % self.P < self.b and budget.can_attack(t):
            return set(Estar)
        return set()


class RandomBlackout:
    def __init__(self, p, rng):
        self.p, self.rng = p, rng

    def decide(self, t, Estar, K, budget):
        if Estar and self.rng.random() < self.p and budget.can_attack(t):
            return set(Estar)
        return set()


class InformativeBlackout:
    """State-aware: blacks out every round in which some intended edge would carry new
    certificate information, whenever the budget allows."""

    def decide(self, t, Estar, K, budget):
        if any(K[a] != K[b] for a, b in Estar) and budget.can_attack(t):
            return set(Estar)
        return set()


# ========================================================== one run
def run(sched, n, s0, adversary, budget, horizon, record=False, stop_at_sync=True):
    """Simulate S-CGD with certificate flooding. Returns dict with
    sigma_star (value agreement), T_sync (certified detection, None if not reached),
    attacked edge sequence (for baselines), counters."""
    full = (1 << n) - 1
    s = list(s0)
    K = [(1 << i) if s[i] == 1 else 0 for i in range(n)]
    sigma_star = max(sigma(v) for v in s0)
    T_sync = 0 if all(k == full for k in K) else None
    Eseq = []
    attack_rounds = []
    bridge_cross = 0
    Ktrace = [] if record else None
    strace = [] if record else None
    for t in range(horizon):
        Estar = sched.intended(t)
        A = adversary.decide(t, Estar, K, budget)
        E = [e for e in Estar if e not in A]
        # an attack round counts against the budget only if it is effective (Definition 2):
        eff = bool(A) and not connected(n, E)
        budget.commit(t, eff)
        if eff:
            attack_rounds.append(t)
        if hasattr(sched, "bridge") and sched.bridge in E:
            bridge_cross += 1
        Eseq.append(E)
        if record:
            Ktrace.append([bin(k).count("1") for k in K])
            strace.append(list(s))
        newK = list(K)
        for a, b in E:
            newK[a] |= K[b]
            newK[b] |= K[a]
        s = [collatz(v) if v > 1 else 1 for v in s]
        for i in range(n):
            if s[i] == 1:
                newK[i] |= 1 << i
        K = newK
        if T_sync is None and all(k == full for k in K):
            T_sync = t + 1
            if stop_at_sync and not record:
                break
    return dict(sigma_star=sigma_star, T_sync=T_sync, Eseq=Eseq, attack_rounds=attack_rounds,
                n_attack=budget.n_attack, onsets=budget.onsets, bridge_cross=bridge_cross,
                Ktrace=Ktrace, strace=strace)


# ========================================================== baselines
def max_consensus_time(n, x0, Eseq, horizon_extra_sched=None):
    x = list(x0)
    target = max(x0)
    if all(v == target for v in x):
        return 0
    for t, E in enumerate(Eseq):
        nx = list(x)
        for a, b in E:
            m = max(x[a], x[b])
            nx[a] = max(nx[a], m)
            nx[b] = max(nx[b], m)
        x = nx
        if all(v == target for v in x):
            return t + 1
    return None


def linear_consensus_time(n, x0, Eseq, eps=1e-3):
    x = np.array(x0, dtype=float)
    r0 = x.max() - x.min()
    if r0 == 0:
        return 0
    for t, E in enumerate(Eseq):
        deg = np.zeros(n)
        for a, b in E:
            deg[a] += 1
            deg[b] += 1
        dx = np.zeros(n)
        for a, b in E:
            w = 1.0 / (1.0 + max(deg[a], deg[b]))
            dx[a] += w * (x[b] - x[a])
            dx[b] += w * (x[a] - x[b])
        x = x + dx
        if x.max() - x.min() <= eps * r0:
            return t + 1
    return None


def extend_eseq(run_out, sched, adversary_cls_state, horizon):
    return run_out["Eseq"]


# ========================================================== bounds
def bound_regime_B(sig, n, W, L):
    return sig + (n - 1) * (2 * W - 1 + L)


def bound_regime_A(sig, n, W, kappa, tau_D):
    if math.isinf(tau_D):
        return sig + (n - 1) * W
    if tau_D <= W:
        return None
    m = math.ceil((n - 1 + kappa) * tau_D / (tau_D - W))
    return sig + W * m


def initial_states(n, M, rng):
    s0 = [rng.randint(1, M) for _ in range(n)]
    s0[rng.randrange(n)] = argmax_sigma(M)
    return s0


# =========================================================================== protocol engine
# Each protocol exposes: informative(Estar) -> bool, step(t, E) -> None, done(t) -> bool.
class CertFlood:
    """S-CGD with certificate flooding: token j is released when s(j) reaches 1 (round sigma_j)."""
    name = "S-CGD (cert.)"

    def __init__(self, n, s0):
        self.n, self.full = n, (1 << n) - 1
        self.s = list(s0)
        self.K = [(1 << i) if self.s[i] == 1 else 0 for i in range(n)]
        self.sig = max(sigma(v) for v in s0)

    def informative(self, E):
        return any(self.K[a] != self.K[b] for a, b in E)

    def step(self, t, E):
        K = self.K
        nK = list(K)
        for a, b in E:
            nK[a] |= K[b]
            nK[b] |= K[a]
        self.s = [collatz(v) if v > 1 else 1 for v in self.s]
        for i in range(self.n):
            if self.s[i] == 1:
                nK[i] |= 1 << i
        self.K = nK

    def done(self, t):
        return all(k == self.full for k in self.K)


class PreFlood(CertFlood):
    """Variant: every robot computes sigma_i locally at t=0 and floods (i, sigma_i); a robot declares
    at the first round at which it holds all n tokens and t >= max_j sigma_j (release times 0)."""
    name = "S-CGD (precomp.)"

    def __init__(self, n, s0):
        super().__init__(n, s0)
        self.K = [1 << i for i in range(n)]

    def step(self, t, E):
        K = self.K
        nK = list(K)
        for a, b in E:
            nK[a] |= K[b]
            nK[b] |= K[a]
        self.K = nK

    diss = None

    def note(self, t):
        if self.diss is None and all(k == self.full for k in self.K):
            self.diss = t

    def done(self, t):
        return t >= self.sig and all(k == self.full for k in self.K)


class MaxCons:
    """Uncertified max-consensus on the initial values (agreement time)."""
    name = "max-consensus"

    def __init__(self, n, s0):
        self.x = list(s0)
        self.target = max(s0)

    def informative(self, E):
        return any(self.x[a] != self.x[b] for a, b in E)

    def step(self, t, E):
        x = self.x
        nx = list(x)
        for a, b in E:
            m = max(x[a], x[b])
            nx[a] = max(nx[a], m)
            nx[b] = max(nx[b], m)
        self.x = nx

    def done(self, t):
        return all(v == self.target for v in self.x)


class LinCons:
    """Uncertified linear average consensus, Metropolis weights, spread <= eps * initial spread."""
    name = "linear"

    def __init__(self, n, s0, eps=1e-3):
        self.n = n
        self.x = np.array(s0, dtype=float)
        self.r0 = self.x.max() - self.x.min()
        self.eps = eps

    def informative(self, E):
        return any(abs(self.x[a] - self.x[b]) > 1e-12 * max(self.r0, 1) for a, b in E)

    def step(self, t, E):
        deg = np.zeros(self.n)
        for a, b in E:
            deg[a] += 1
            deg[b] += 1
        dx = np.zeros(self.n)
        x = self.x
        for a, b in E:
            w = 1.0 / (1.0 + max(deg[a], deg[b]))
            dx[a] += w * (x[b] - x[a])
            dx[b] += w * (x[a] - x[b])
        self.x = x + dx

    def done(self, t):
        return self.r0 == 0 or (self.x.max() - self.x.min()) <= self.eps * self.r0


class TargetedBlackout:
    """State-aware: blacks out every round (at or after round t0) in which some intended edge would
    change the attacked protocol's state, whenever the budget allows. t0 = 0 is the greedy
    adversary; t0 = sigma* saves the whole budget until the last robot reaches 1."""

    def __init__(self, t0=0):
        self.t0 = t0

    def decide(self, t, Estar, proto, budget):
        if t >= self.t0 and Estar and proto.informative(Estar) and budget.can_attack(t):
            return set(Estar)
        return set()


class ObliviousWrap:
    """Adapter for oblivious adversaries written for run()."""

    def __init__(self, adv):
        self.adv = adv

    def decide(self, t, Estar, proto, budget):
        return self.adv.decide(t, Estar, None, budget)


def run_protocol(sched, n, proto, adversary, budget, horizon, probe_t=None):
    """Returns (T, attack_rounds, probe). T is the first round t with proto.done(t) (None if never).
    If probe_t is given, probe records the budget level g, the number of tokens not yet held by all
    robots at round probe_t, and the length of the first attack interval starting at or after it."""
    attack_rounds = []
    probe = {}
    if proto.done(0):
        return 0, attack_rounds, probe
    for t in range(horizon):
        if probe_t is not None and t == probe_t:
            probe["g"] = budget.g
            if hasattr(proto, "K"):
                full = (1 << n) - 1
                allK = full
                for k in proto.K:
                    allK &= k
                probe["incomplete"] = n - bin(allK).count("1")
        Estar = sched.intended(t)
        A = adversary.decide(t, Estar, proto, budget)
        E = [e for e in Estar if e not in A] if A else Estar
        eff = bool(A) and not connected(n, E)
        budget.commit(t, eff)
        if eff:
            attack_rounds.append(t)
        proto.step(t, E)
        if hasattr(proto, "note"):
            proto.note(t + 1)
        if proto.done(t + 1):
            break
    else:
        t = horizon  # not done
    if probe_t is not None:
        s_ = set(attack_rounds)
        after = [u for u in s_ if u >= probe_t]
        first = min(after) if after else None
        if first is None:
            probe["burst"] = 0
        else:
            b = 0
            while first + b in s_:
                b += 1
            probe["burst"] = b
    T = (t + 1) if (t < horizon and proto.done(t + 1)) else None
    return T, attack_rounds, probe


class CutCover:
    """Instance-level adversary (Theorem 6): isolates robot v from round t0 on by removing all its
    intended edges whenever the budget allows (such rounds are attack rounds, since v is isolated)."""

    def __init__(self, v, t0=0):
        self.v, self.t0 = v, t0

    def decide(self, t, Estar, proto, budget):
        if t < self.t0:
            return set()
        cross = {e for e in Estar if self.v in e}
        if cross and budget.can_attack(t):
            return cross
        return set()


def coverable(cross, attackable, t0, H, kappa, tau_D, tau_F, eta=1.0):
    """Finite-horizon test of Theorem 6: is there an admissible attack-round set R containing every
    crossing round in [t0, H)?  Pareto dynamic program over the budget state (g, h, prev), exact
    rational arithmetic. cross, attackable: sequences of booleans indexed by round."""
    from fractions import Fraction as Fr
    invD = Fr(0) if math.isinf(tau_D) else 1 / Fr(tau_D).limit_denominator(10**6)
    invF = Fr(0) if math.isinf(tau_F) else 1 / Fr(tau_F).limit_denominator(10**6)
    K, E = Fr(kappa).limit_denominator(10**6), Fr(eta).limit_denominator(10**6)
    front = {False: [(Fr(0), Fr(0))], True: []}
    for t in range(t0, H):
        new = {False: [], True: []}
        for prev, states in front.items():
            for g, h in states:
                choices = [1] if cross[t] else ([0, 1] if attackable[t] else [0])
                for a in choices:
                    onset = a == 1 and not prev
                    g2 = a + max(Fr(0), g - invD)
                    h2 = (1 if onset else 0) + max(Fr(0), h - invF)
                    if g2 > K or h2 > E:
                        continue
                    new[a == 1].append((g2, h2))
        for key in new:
            pts = sorted(set(new[key]))
            pareto, best_h = [], None
            for g, h in pts:
                if best_h is None or h < best_h:
                    pareto.append((g, h)); best_h = h
            new[key] = pareto
        front = new
        if not front[False] and not front[True]:
            return False
    return True


# =========================================================================== bounds (Theorem 2)
def T_bound_c(sig, n, W, kappa, tau_D, tau_F, eta):
    g = 1 - 1 / tau_D - (W - 1) / tau_F
    if g <= 0:
        return None
    return sig + math.ceil((W * (n - 1) + kappa + (W - 1) * (eta + 1)) / g)


def T_bound_b_general(sig, n, W, L, tau_F, eta):
    g = 1 - (W + L - 1) / tau_F
    if g <= 0:
        return None
    return sig + math.ceil((W * (n - 1) + (W + L - 1) * (eta + 1)) / g)


def T_bound_density(sig, n, rho, beta, kappa, tau_D):
    """Theorem 5: every cut crossed in >= rho*T - beta rounds of any T-window; needs rho > 1/tau_D."""
    g = rho - (0.0 if math.isinf(tau_D) else 1 / tau_D)
    if g <= 0:
        return None
    return sig + (n - 1) * (math.floor((beta + kappa) / g) + 1)


def guaranteed(W, kappa, tau_D, tau_F, eta=1):
    """Theorem 4 (eta = 1, or any eta >= 1 with integer tau_F)."""
    L = max(0, math.floor(ell_max(kappa, tau_D) + 1e-12))
    F = math.ceil(tau_F - 1e-12)
    from fractions import Fraction as Fr
    tD = Fr(tau_D).limit_denominator(10**6) if not math.isinf(tau_D) else None
    if L == 0 or tD is None or tD > W or F >= W + L or (F - W + 1) * (tD - 1) > W - 1:
        return True
    return False


def blocking_burst(W, kappa, tau_D, tau_F):
    """Burst length ell used by the Theorem 3 construction when certification is blockable."""
    L = max(0, math.floor(ell_max(kappa, tau_D) + 1e-12))
    F = math.ceil(tau_F - 1e-12)
    return max(1, F - W + 1) if L >= 1 else 0


# =========================================================================== density estimates
def density_lower(conn, rho):
    """beta(rho) = max over windows [t, t+T) of (rho*T - #connected rounds) (max-subarray)."""
    best = cur = 0.0
    for c in conn:
        cur = max(0.0, cur + rho - c)
        best = max(best, cur)
    return best
