"""Figures 1 to 5 of the paper (vector PDF, IEEE single-column width 3.5 in).
Reads e2.json and e4.json from the working directory; writes the PDFs to $FIG_OUT (default ../)."""
import json, math, os, random
import matplotlib
import matplotlib.ticker
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scgd_dos import *

OUT = os.environ.get("FIG_OUT", "../")
C = dict(blue="#0072B2", orange="#D55E00", green="#009E73", pink="#CC79A7",
         ink="#222222", muted="#777777", grid="#DDDDDD", atk="#D55E00", ok="#009E73")
plt.rcParams.update({"font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "font.size": 8, "axes.linewidth": 0.6,
                     "axes.edgecolor": C["muted"], "xtick.color": C["ink"], "ytick.color": C["ink"],
                     "axes.labelcolor": C["ink"], "legend.frameon": False, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False})
COLW = 3.5


# ========================================================== Fig. 1: two layers
def fig1():
    n, M, r, H = 30, 500, 0.25, 400
    rng = random.Random(500)
    sch = RWPUDC(n, r, 6000, rng)
    W = joint_connectivity_window(sch, n, 5600)
    s0 = initial_states(n, M, rng)
    out = run(sch, n, s0, InformativeBlackout(), Budget(5, 1.25, 1), H, record=True)
    T = out["T_sync"]
    fig, (a, b) = plt.subplots(2, 1, figsize=(COLW, 3.0), sharex=True,
                               gridspec_kw=dict(height_ratios=[1.1, 1], hspace=0.6))
    order = sorted(range(n), key=lambda i: sigma(s0[i]))
    pick = [order[-1], order[int(0.75 * n)], order[n // 2], order[n // 4]]
    cols = [C["blue"], C["orange"], C["green"], C["pink"]]
    lss = ["-", "--", "-.", ":"]
    for i, c, ls in zip(pick, cols, lss):
        ys = [st[i] for st in out["strace"]][: T + 5]
        a.plot(range(len(ys)), ys, color=c, lw=1.0, ls=ls, label=f"$s_0={s0[i]}$ ($\\sigma={sigma(s0[i])}$)")
    a.set_yscale("log")
    a.set_yticks([1, 10, 100, 1000, 10000])
    a.set_ylabel("state $s_t(i)$")
    a.legend(fontsize=7, loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=2, handlelength=1.8, columnspacing=0.8)
    a.text(-0.2, 1.0, "(a)", transform=a.transAxes, fontsize=8, va="bottom")
    kt = out["Ktrace"][: T + 5]
    mn = [min(k) for k in kt]
    av = [sum(k) / n for k in kt]
    for t in out["attack_rounds"]:
        if t < T + 5:
            b.axvspan(t - 0.5, t + 0.5, color=C["atk"], alpha=0.3, lw=0)
    b.plot(range(len(av)), av, color=C["blue"], lw=1.0, label="mean $|K_t(i)|$")
    b.plot(range(len(mn)), mn, color=C["ink"], lw=1.0, ls="--", label="min $|K_t(i)|$")
    b.axvline(out["sigma_star"], color=C["muted"], lw=0.6, ls=":")
    b.axvline(T, color=C["muted"], lw=0.6, ls=":")
    b.text(out["sigma_star"] - 2, n * 0.18, "$\\sigma^\\star$", ha="right", fontsize=7, color=C["ink"])
    b.text(T + 2, n * 0.18, "$T_{\\rm sync}$", ha="left", fontsize=7, color=C["ink"])
    b.set_ylabel("tokens held $|K_t(i)|$")
    b.set_xlabel("round $t$")
    b.set_ylim(0, n + 1)
    hs, ls_ = b.get_legend_handles_labels()
    hs.append(Rectangle((0, 0), 1, 1, color=C["atk"], alpha=0.3)); ls_.append("attack round")
    b.legend(hs, ls_, fontsize=7, loc="upper left", bbox_to_anchor=(0.0, 1.36), ncol=3)
    b.text(-0.2, 1.0, "(b)", transform=b.transAxes, fontsize=8, va="bottom")
    fig.savefig(OUT + "fig1_two_layers.pdf", bbox_inches="tight")
    plt.close(fig)
    return dict(W=W, sigma=out["sigma_star"], T=T, attacks=len([t for t in out["attack_rounds"] if t < T]))


# ========================================================== Fig. 2: windows
def fig2():
    W, L, tF = 10, 2, 13
    onsets = [0, 13, 26, 39]
    atk = {o + k for o in onsets for k in range(L)}
    Tmax = 46
    fig, ax = plt.subplots(figsize=(COLW, 1.6))
    for t in range(Tmax):
        ax.add_patch(Rectangle((t - 0.46, 0), 0.92, 1, color=C["atk"] if t in atk else C["ok"],
                               alpha=0.85 if t in atk else 0.35, lw=0))
    for o in onsets:
        ax.annotate("", xy=(o, 1.02), xytext=(o, 1.5),
                    arrowprops=dict(arrowstyle="-|>", color=C["ink"], lw=0.6, mutation_scale=6))
    ax.text(13.5, 1.62, "onsets $\\geq\\tau_F=13$ apart", ha="center", fontsize=7)

    def bracket(x0, x1, y, txt):
        ax.plot([x0 - 0.46, x0 - 0.46, x1 + 0.46, x1 + 0.46], [y + 0.12, y, y, y + 0.12], color=C["ink"], lw=0.9)
        ax.text((x0 + x1) / 2, y - 0.3, txt, ha="center", va="top", fontsize=7, color=C["ink"])
    bracket(4, 18, -0.25, "$\\lfloor\\tau_F+\\ell_{\\max}\\rfloor=15$: window $[4,18]$, longest benign run 9 $<W$")
    bracket(4, 24, -1.15, "$2W-1+L=21$: window $[4,24]$ contains benign run $[15,24]$")
    ax.add_patch(Rectangle((15 - 0.46, 0), 9.92, 1, fill=False, ec=C["blue"], lw=1.2))
    ax.set_xlim(-0.8, Tmax - 0.3)
    ax.set_ylim(-2.1, 1.9)
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    ax.set_xticks(range(0, Tmax, 5))
    ax.set_xlabel("round $t$")
    ax.legend(handles=[Rectangle((0, 0), 1, 1, color=C["atk"], alpha=0.85),
                       Rectangle((0, 0), 1, 1, color=C["ok"], alpha=0.35),
                       Rectangle((0, 0), 1, 1, fill=False, ec=C["blue"], lw=1.2)],
              labels=["attack round", "benign round", "benign run of $W$"], loc="upper right", fontsize=7, ncol=3,
              bbox_to_anchor=(1.02, 1.3), handlelength=1.2, columnspacing=0.8)
    fig.savefig(OUT + "fig2_windows.pdf", bbox_inches="tight")
    plt.close(fig)


# ========================================================== Fig. 3: necessity
def fig3():
    W, L = 10, 2
    P = W + L - 1
    fig, (g, ax) = plt.subplots(2, 1, figsize=(COLW, 2.35), gridspec_kw=dict(height_ratios=[0.8, 1.25], hspace=0.55))
    k = 8
    for i in range(k - 1):
        br = i == 3
        g.plot([i, i + 1], [0, 0], color=C["orange"] if br else C["ink"], lw=1.6 if br else 0.9,
               ls=(0, (3, 2)) if br else "-")
    g.scatter(range(k), [0] * k, s=40, color="white", edgecolor=C["ink"], zorder=3, lw=0.8)
    g.text(3.5, 0.3, "bridge $e_{\\rm b}$", ha="center", fontsize=7, color=C["ink"])
    for x0, x1, lab in ((0, 3, "$V_1$"), (4, 7, "$V_2$")):
        g.plot([x0 - 0.1, x0 - 0.1, x1 + 0.1, x1 + 0.1], [-0.3, -0.4, -0.4, -0.3], color=C["muted"], lw=0.8)
        g.text((x0 + x1) / 2, -0.75, lab, ha="center", fontsize=7)
    g.set_xlim(-0.6, k - 0.4); g.set_ylim(-1.0, 0.6); g.axis("off")
    g.set_title("(a) intended path ($n=8$ shown); other edges at least once per $W$ rounds", fontsize=7.5, loc="left")
    Tm = 40
    for t in range(Tm):
        on = (t % P) < L
        ax.add_patch(Rectangle((t - 0.45, 2.1), 0.9, 0.7, color=C["blue"] if on else "#E6E6E6", lw=0))
        ax.add_patch(Rectangle((t - 0.45, 1.15), 0.9, 0.7, color=C["atk"] if on else "#E6E6E6", lw=0))
        ax.add_patch(Rectangle((t - 0.45, 0.2), 0.9, 0.7, color="#E6E6E6", lw=0))
    ax.text(-1.0, 2.45, "$e_{\\rm b}\\in E^*_t$", ha="right", va="center", fontsize=7)
    ax.text(-1.0, 1.5, "$e_{\\rm b}\\in A_t$", ha="right", va="center", fontsize=7)
    ax.text(-1.0, 0.55, "$e_{\\rm b}\\in E_t$", ha="right", va="center", fontsize=7)
    ax.annotate("", xy=(P, 3.05), xytext=(0, 3.05), arrowprops=dict(arrowstyle="<->", lw=0.6, color=C["ink"]))
    ax.text(P / 2, 3.2, "$W+\\ell-1=11$", ha="center", fontsize=7)
    ax.set_xlim(-0.7, Tm - 0.3); ax.set_ylim(0, 3.6); ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    ax.set_xlabel("round $t$")
    ax.legend(handles=[Rectangle((0, 0), 1, 1, color=C["blue"]), Rectangle((0, 0), 1, 1, color=C["atk"]),
                       Rectangle((0, 0), 1, 1, color="#E6E6E6")],
              labels=["scheduled", "removed", "absent"], fontsize=7, ncol=3, loc="upper right",
              bbox_to_anchor=(1.0, 1.38), handlelength=1.2)
    ax.set_title("(b) $W=10$, $\\ell=2$", fontsize=7.5, loc="left")
    fig.savefig(OUT + "fig3_necessity.pdf", bbox_inches="tight")
    plt.close(fig)


# ========================================================== Fig. 4: exact characterization
def fig4():
    import numpy as np
    W = 10
    e4 = json.load(open("e4.json"))
    e2 = json.load(open("e2.json"))
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.2), sharey=True, gridspec_kw=dict(wspace=0.08))
    xs = np.exp(np.linspace(math.log(1.2), math.log(45), 700))
    ys = np.linspace(0.5, 16.5, 400)
    for ax, kappa in zip(axs, (1, 2, 3)):
        Z = np.array([[1.0 if guaranteed(W, kappa, x, y) else 0.0 for x in xs] for y in ys])
        ax.contourf(xs, ys, Z, levels=[-0.5, 0.5, 1.5], colors=[C["atk"], C["ok"]], alpha=0.28)
        cs = ax.contourf(xs, ys, Z, levels=[-0.5, 0.5, 1.5], colors="none", hatches=["////", None])
        for coll in getattr(cs, "collections", [cs]):
            try:
                coll.set_edgecolor(C["atk"]); coll.set_linewidth(0)
            except Exception:
                pass
        ax.contour(xs, ys, Z, levels=[0.5], colors=C["ink"], linewidths=0.8)
        for r in e4:
            if r["kappa"] != kappa:
                continue
            allc = r["conv"] == r["trials"]
            ax.scatter(r["tau_D"], r["tau_F"], marker="o" if allc else "x", s=8, lw=0.6, zorder=4,
                       facecolor="none" if allc else C["ink"], edgecolor=C["ink"] if allc else None,
                       color=None if allc else C["ink"])
        if kappa == 1:
            for r in e2:
                tD = float(r["tau_D"])
                if tD > 45 or tD == 11:
                    continue  # tau_D = 11 omitted for legibility (same outcome as 10.5 and 12)
                blocked = r["bridge"]["conv"] == 0 and r["periodic"]["conv"] == 0
                ax.scatter(tD, 1.0, marker="x" if blocked else "o", s=9, lw=0.7, zorder=4,
                           facecolor=C["ink"] if blocked else "none", edgecolor=None if blocked else C["ink"],
                           color=C["ink"] if blocked else None)
        ax.axvline(W, color=C["ink"], lw=0.5, ls=":")
        ax.set_xscale("log"); ax.set_xlim(1.2, 45); ax.set_ylim(0.3, 16.5)
        ax.set_yticks([1, 4, 7, 10, 13, 16])
        ax.set_xticks([1.5, 2, 3, 5, 10, 20, 40]); ax.set_xticklabels(["1.5", "2", "3", "5", "10", "20", "40"])
        ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
        ax.set_xlabel("$\\tau_D$ (rounds)", labelpad=1)
        ax.set_title(f"$\\kappa={kappa}$", fontsize=8)
    axs[0].set_ylabel("$\\tau_F$ (rounds)")
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    h = [Patch(facecolor=C["ok"], alpha=0.28), Patch(facecolor=C["atk"], alpha=0.28, hatch="////", edgecolor=C["atk"]),
         Line2D([], [], marker="o", ls="", mfc="none", mec=C["ink"], ms=4),
         Line2D([], [], marker="x", ls="", color=C["ink"], ms=4)]
    fig.legend(h, ["guaranteed (Theorem 4)", "blockable (Theorem 4)", "simulation: all runs certify",
                   "simulation: no run certifies"], loc="lower center", ncol=4, fontsize=7,
               bbox_to_anchor=(0.5, -0.2), handlelength=1.4)
    fig.savefig(OUT + "fig4_phase.pdf", bbox_inches="tight")
    plt.close(fig)


# ========================================================== Fig. 5: duty sweep
def fig5():
    import numpy as np
    W, n, kappa, sig = 10, 30, 1, 143
    e2 = json.load(open("e2.json"))
    fig, (top, mid, low) = plt.subplots(3, 1, figsize=(COLW, 3.3), sharex=True,
                                        gridspec_kw=dict(height_ratios=[0.2, 0.9, 1.0], hspace=0.12))
    finite = [r for r in e2 if float(r["tau_D"]) < 1e9]
    styles = [("bridge", "bridge-blocking", C["orange"], "o", 5.5, "white"),
              ("periodic", "periodic, phase-searched", C["blue"], "s", 4.0, C["blue"]),
              ("random", "random blackout", C["green"], "^", 4.0, C["green"])]
    for key, lab, col, mk, ms, mfc in styles:
        conv = [(float(r["tau_D"]), r[key]["maxT"]) for r in finite if r[key]["maxT"] is not None]
        inf = [float(r["tau_D"]) for r in finite if r[key]["maxT"] is None]
        seg = [c for c in conv if c[0] > W] if key != "random" else conv
        low.plot([c[0] for c in seg], [c[1] for c in seg], color=col, lw=1.0, marker=mk, ms=ms, mfc=mfc, label=lab)
        top.plot(inf, [1] * len(inf), ls="none", marker=mk, ms=ms, color=col, mfc=mfc)
    xs = np.linspace(W + 0.02, 45, 3000)
    bd = [sig + W * math.ceil((n - 1 + kappa) * x / (x - W)) for x in xs]
    mid.step(xs, bd, where="post", color=C["ink"], lw=1.0, ls="--", label="bound $\\sigma^\\star+D_a$, Theorem 2(a)")
    mid.set_yscale("log"); mid.set_ylim(400, 2e4)
    mid.set_yticks([500, 1000, 2000, 5000, 10000])
    mid.yaxis.set_major_formatter(matplotlib.ticker.ScalarFormatter())
    mid.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    mid.legend(fontsize=7, loc="upper right")
    low.axhline(318, color=C["muted"], lw=0.8, label="worst without attack (318)")
    low.set_ylim(280, 520)
    for a_ in (top, mid, low):
        a_.axvline(W, color=C["muted"], lw=0.6, ls=":")
    top.set_yticks([1]); top.set_yticklabels(["$\\infty$"]); top.set_ylim(0.5, 1.5)
    top.spines["bottom"].set_visible(False)
    top.tick_params(axis="x", which="both", length=0)
    mid.tick_params(axis="x", which="both", length=0)
    low.set_xscale("log")
    low.set_xticks([5, 8, 10, 12, 15, 20, 40]); low.set_xticklabels(["5", "8", "10", "12", "15", "20", "40"])
    low.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    low.set_xlim(4.5, 45)
    low.set_xlabel("$\\tau_D$ (rounds), $\\kappa=1$, onsets unconstrained")
    mid.set_ylabel("bound")
    low.set_ylabel("worst $T_{\\rm sync}$")
    low.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.45, -0.38), ncol=2)
    fig.savefig(OUT + "fig5_duty.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    info = fig1(); print("fig1", info)
    fig2(); fig3(); fig4(); fig5()
