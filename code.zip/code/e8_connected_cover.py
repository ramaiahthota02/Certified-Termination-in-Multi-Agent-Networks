"""Cut-independent sufficient check of Theorem 6 on the RWP schedules of e3 (same seeds).
Every cut is crossed in every round whose intended graph is connected, so if the set of connected
rounds is not coverable from t0, no cut is coverable from t0. Tested from t0 in {0, 500, ..., 5500}
on the 6000-round horizon, for scenarios (D) and (H) (kappa = 5, onsets unconstrained)."""
import json, math, random
from scgd_dos import *

n, r, H, TR = 30, 0.25, 6000, 20
T0 = list(range(0, H, 500))
rows = []
for tr in range(TR):
    rng = random.Random(500 + tr)
    sch = RWPUDC(n, r, H, rng)
    conn = [connected(n, sch.intended(t)) for t in range(H)]
    att = [bool(sch.intended(t)) for t in range(H)]
    frac = sum(conn) / H
    rho = 0.9 * frac
    res = dict(trial=tr, frac=frac)
    for sname, tD in (("D", 1.0 / (0.9 * rho)), ("H", 1.25)):
        res[sname] = [bool(coverable(conn, att, t0, H, 5, tD, 1)) for t0 in T0]
    rows.append(res)
    print(res, flush=True)
json.dump(dict(t0=T0, rows=rows), open("e8.json", "w"), indent=1)
for s in ("D", "H"):
    print(s, "trials with connected rounds coverable from some tested t0:", sum(any(x[s]) for x in rows))

# Analytic complement: a run of more than L consecutive connected rounds cannot be covered, since every
# round of it would have to be an attack round. Record the start of the last such run (for L of (H),
# L = 21, the larger of the two scenarios), so every t0 up to it is non-coverable for every cut.
last = []
for tr in range(TR):
    rng = random.Random(500 + tr)
    sch = RWPUDC(n, r, H, rng)
    conn = [connected(n, sch.intended(t)) for t in range(H)]
    L = math.floor(ell_max(5, 1.25) + 1e-12)
    start, c, best = None, 0, None
    for t, x in enumerate(conn):
        if x:
            c += 1
            if c == L + 1:
                best = t - L
        else:
            c = 0
    last.append(best)
print("L(H) =", math.floor(ell_max(5, 1.25) + 1e-12), "start of last run longer than L: min over trials", min(last), "median", sorted(last)[10])
d = json.load(open("e8.json")); d["last_long_run_start"] = last; json.dump(d, open("e8.json", "w"), indent=1)
