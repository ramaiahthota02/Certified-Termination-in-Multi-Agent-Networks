"""Certifies T_sync = infinity for the divergent periodic-blackout runs of Table III (tau_D <= W):
after sigma*, the joint state (certificate sets, budget recursions g and h, schedule phase t mod W,
attack phase t mod P) is compared at two rounds one common period apart. Equality implies that
the state sequence is periodic from then on, so no certificate set ever grows."""
import math, random
from scgd_dos import *
from fractions import Fraction as Fr
class ExactBudget:
    """Budget recursions in exact rational arithmetic (no rounding)."""
    def __init__(self, kappa, tau_D, tau_F, eta=1):
        self.kappa=Fr(kappa); self.eta=Fr(eta); self.inv=1/Fr(tau_D); self.invF=1/Fr(tau_F)
        self.g=Fr(0); self.h=Fr(0); self.prev_attack=False
    def can_attack(self,t):
        if 1+max(Fr(0),self.g-self.inv)>self.kappa: return False
        if not self.prev_attack and 1+max(Fr(0),self.h-self.invF)>self.eta: return False
        return True
    def commit(self,t,attacked):
        onset=attacked and not self.prev_attack
        self.g=(1 if attacked else 0)+max(Fr(0),self.g-self.inv)
        self.h=(1 if onset else 0)+max(Fr(0),self.h-self.invF)
        self.prev_attack=attacked

n, M, W, TR = 30, 500, 10, 20
kappa, tau_F = 1, 1

def joint_state_run(sch, s0, P, ph, tD, H):
    full = (1 << n) - 1
    s = list(s0); K = [(1 << i) if s[i] == 1 else 0 for i in range(n)]
    B = ExactBudget(kappa, tD, tau_F); adv = PeriodicBlackout(P, 1, ph)
    per = W * P // math.gcd(W, P)
    snaps = {}
    sig = max(sigma(v) for v in s0)
    for t in range(H):
        if t >= sig and t % per == 0:
            key = (tuple(K), B.g, B.h, B.prev_attack)
            if key in snaps:
                return "periodic", t
            snaps[key] = t
        Estar = sch.intended(t); A = adv.decide(t, Estar, K, B)
        E = [e for e in Estar if e not in A]
        B.commit(t, bool(A) and not connected(n, E))
        nK = list(K)
        for a, b in E:
            nK[a] |= K[b]; nK[b] |= K[a]
        s = [collatz(v) if v > 1 else 1 for v in s]
        for i in range(n):
            if s[i] == 1: nK[i] |= 1 << i
        K = nK
        if all(k == full for k in K):
            return "synced", t + 1
    return "undecided", H

summary = {}
for tD in (5, 8, 10):
    cert = 0
    for tr in range(TR):
        rng = random.Random(7000 + tr)
        sch = RoundRobinPath(n, W, rng)
        s0 = initial_states(n, M, rng)
        found = None
        for P in range(math.ceil(tD), math.ceil(tD) + W):
            for ph in range(P):
                res, _ = joint_state_run(sch, s0, P, ph, tD, 20000)
                if res == "periodic":
                    found = (P, ph); break
            if found: break
        cert += found is not None
    summary[tD] = f"{cert}/{TR} trials certified non-synchronizing (periodic joint state)"
print(summary)
