"""Validation of the exact characterization (Theorem 4) on a (tau_D, tau_F) grid, W = 10, eta = 1.
Topology: path P_30 whose middle edge follows the cluster schedule of Theorem 3 with burst length ell,
other edges once per W rounds at random phase. Adversary: blocks the middle edge whenever the budget
allows. ell is the Theorem 3 burst length where blocking is predicted, and the adversary's best
attempt min(L, max(1, F - W + 1)) elsewhere."""
import json, math, random
from scgd_dos import *
n, M, W, H, TR = 30, 500, 10, 5000, 5
TAU_D = [1.25, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10, 12, 15]
TAU_F = list(range(2, 17))
rows = []
mism = 0
for kappa in (1, 2, 3):
    for tD in TAU_D:
        L = max(0, math.floor(ell_max(kappa, tD) + 1e-12))
        for tF in TAU_F:
            pred = guaranteed(W, kappa, tD, tF)
            F = math.ceil(tF)
            ell = min(L, max(1, F - W + 1)) if L >= 1 else 1
            conv, cross = 0, 0
            for tr in range(TR):
                rng = random.Random(hash((kappa, tD, tF, tr)) & 0xFFFFFFFF)
                sch = BridgePath(n, W, max(ell, 1), rng)
                s0 = initial_states(n, M, rng)
                adv = BridgeBlocker(sch.bridge) if L >= 1 else NoAttack()
                out = run(sch, n, s0, adv, Budget(kappa, tD, tF), H)
                conv += out["T_sync"] is not None
                cross = max(cross, out["bridge_cross"]) if out["T_sync"] is None else cross
            ok = (conv == TR) if pred else (conv == 0)
            mism += not ok
            rows.append(dict(kappa=kappa, tau_D=tD, tau_F=tF, L=L, ell=ell, pred=pred, conv=conv,
                             trials=TR, ok=ok, max_cross_nonconv=cross))
print("points", len(rows), "mismatches", mism)
json.dump(rows, open("e4.json", "w"), indent=0)
