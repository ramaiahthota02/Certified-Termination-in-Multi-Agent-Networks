"""E1: sharp onset-frequency threshold on the bridge path (Theorem 3)."""
import json, math, random, statistics as st
from scgd_dos import *
n, M, W, H, TR = 30, 500, 10, 20000, 20
rows = []
for L in (1, 2, 3):
    kappa, tau_D = L, (W + L - 1) / L
    assert math.floor(ell_max(kappa, tau_D)) == L
    for tau_F in range(W - 2, W + L + 3):
        Ts, conv, cross, bnds = [], 0, [], []
        for tr in range(TR):
            rng = random.Random(1000 * L + 17 * tau_F + tr)
            sch = BridgePath(n, W, L, rng)
            s0 = initial_states(n, M, rng)
            out = run(sch, n, s0, BridgeBlocker(sch.bridge), Budget(kappa, tau_D, tau_F), H)
            cross.append(out["bridge_cross"])
            b = bound_regime_B(out["sigma_star"], n, W, L)
            bnds.append(b)
            if out["T_sync"] is not None:
                conv += 1; Ts.append(out["T_sync"])
        pred = "diverge" if tau_F <= W + L - 1 else "converge"
        r = dict(L=L, kappa=kappa, tau_D=round(tau_D, 3), tau_F=tau_F, pred=pred, conv=conv, trials=TR,
                 med=st.median(Ts) if Ts else None,
                 q1=sorted(Ts)[len(Ts)//4] if Ts else None, q3=sorted(Ts)[(3*len(Ts))//4] if Ts else None,
                 maxT=max(Ts) if Ts else None, bound_min=min(bnds), max_ratio=max(t/b for t,b in zip(Ts,bnds)) if Ts else None,
                 max_cross=max(cross) if conv==0 else None)
        rows.append(r); print(r)
json.dump(rows, open("e1.json", "w"), indent=1)
