"""Table I: maximal Collatz total stopping time Sigma(M) = max_{m <= M} sigma(m) and a maximizer.
Writes t1.json and prints the table rows as they appear in the paper."""
import json
from scgd_dos import sigma

rows = []
best_sigma, best_m = 0, 1
limit = 10 ** 6
targets = [10 ** 2, 500, 10 ** 3, 10 ** 4, 10 ** 5, 10 ** 6]
ti = 0
for m in range(1, limit + 1):
    s = sigma(m)
    if s > best_sigma:
        best_sigma, best_m = s, m
    while ti < len(targets) and m == targets[ti]:
        import math
        lg = math.log2(m)
        rows.append(dict(M=m, m_star=best_m, Sigma=best_sigma,
                         ratio_log=round(best_sigma / lg, 1), ratio_log2=round(best_sigma / lg ** 2, 2)))
        print(rows[-1], flush=True)
        ti += 1
json.dump(rows, open("t1.json", "w"), indent=1)
