"""Exact worst case over ALL admissible attacks on a small instance: path P_n with a round-robin
intended schedule (one edge per round, edge k present at rounds t = k mod W, W = n-1), tokens released
at round 0 (sigma* = 0), eta = 1. Layered reachability over (token sets, g, h, prev) in exact rational
arithmetic. Reports the worst-case dissemination time, the smallest applicable bound of Theorem 2,
and whether the worst case is infinite (compared with Theorem 4)."""
import json, math
from fractions import Fraction as Fr
from scgd_dos import guaranteed, ell_max, coverable

def worst(n, kappa, tD, tF, eta=1, H=400):
    W = n - 1
    edges = [(k, k + 1) for k in range(n - 1)]
    full = (1 << n) - 1
    invD, invF = 1 / Fr(tD), 1 / Fr(tF)
    K0 = tuple(1 << i for i in range(n))
    states = {(K0, Fr(0), Fr(0), False)}
    for t in range(H):
        if all(all(k == full for k in s[0]) for s in states):
            return t
        a_, b_ = edges[t % W]
        new = set()
        for K, g, h, prev in states:
            if all(k == full for k in K):
                continue  # done paths no longer matter for the worst case
            for att in (0, 1):
                onset = att and not prev
                g2 = att + max(Fr(0), g - invD)
                h2 = (1 if onset else 0) + max(Fr(0), h - invF)
                if g2 > kappa or h2 > eta:
                    continue
                if att:
                    K2 = K
                else:
                    K2 = list(K); K2[a_] |= K[b_]; K2[b_] |= K[a_]; K2 = tuple(K2)
                new.add((K2, g2, h2, bool(att)))
        states = new
        if not states:
            return t + 1
    return None  # still incomplete at the horizon

def bounds(n, kappa, tD, tF, eta=1):
    W = n - 1
    L = max(0, math.floor(ell_max(kappa, tD) + 1e-12))
    F = math.ceil(tF)
    cands = []
    if tD > W:
        cands.append(W * math.ceil((n - 1 + kappa) * tD / (tD - W)))
    if F > W + L - 1:
        g = 1 - (W + L - 1) / F
        cands.append(min(math.ceil((W * (n - 1) + (W + L - 1) * (eta + 1)) / g), (n - 1) * (2 * W - 1 + L)))
    g = 1 - 1 / tD - (W - 1) / F
    if g > 0:
        cands.append(math.ceil((W * (n - 1) + kappa + (W - 1) * (eta + 1)) / g))
    if L == 0:
        cands.append((n - 1) * W)
    return min(cands) if cands else None

def instance_blockable(n, kappa, tD, tF, H=240):
    """Theorem 6 on this schedule: some cut eventually coverable (checked from t0 = 0..W-1 on a long
    horizon; the schedule is W-periodic). Cuts of a path: any nonempty proper subset; a cut is crossed
    in the rounds of the path edges it separates."""
    W = n - 1
    best = False
    for mask in range(1, (1 << n) - 1):
        sep = [k for k in range(n - 1) if ((mask >> k) & 1) != ((mask >> (k + 1)) & 1)]
        cross = [(t % W) in sep for t in range(H)]
        att = [True] * H
        if any(coverable(cross, att, t0, H, kappa, tD, tF) for t0 in range(W)):
            return True
    return False

rows = []
for n in (4, 5):
    for kappa in (1, 2, 3):
        for tD in (1.5, 2, 3, 4.5, 6):
            for tF in (2, 3, 4, 5, 6, 8):
                g = guaranteed(n - 1, kappa, tD, tF)
                w = worst(n, Fr(kappa), Fr(tD), Fr(tF))
                b = bounds(n, kappa, tD, tF)
                ib = instance_blockable(n, kappa, tD, tF)
                rows.append(dict(n=n, W=n - 1, kappa=kappa, tau_D=tD, tau_F=tF, guaranteed=g, worst=w, bound=b,
                                 agree_thm4=(w is not None) or not g, instance_blockable=ib,
                                 agree_thm6=(w is None) == ib))
                print(rows[-1], flush=True)
json.dump(rows, open("e6.json", "w"), indent=0)
ok = [r for r in rows if r["guaranteed"]]
print("points", len(rows), "thm4 sufficiency never violated", all(r["agree_thm4"] for r in rows),
      "thm6 agree", sum(r["agree_thm6"] for r in rows), "finite", sum(r["worst"] is not None for r in rows),
      "ratio bound/worst: min %.2f median %.2f max %.2f" % (
          min(r["bound"] / r["worst"] for r in ok if r["worst"]),
          sorted(r["bound"] / r["worst"] for r in ok if r["worst"])[len(ok) // 2],
          max(r["bound"] / r["worst"] for r in ok if r["worst"])))
