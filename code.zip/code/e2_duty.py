"""E2: duty-cycle threshold tau_D* = W (Theorem 2(a) and Theorem 3 with L = 1),
round-robin path, kappa = 1, onset frequency unconstrained (tau_F = 1)."""
import json, math, random, statistics as st
from scgd_dos import *
n, M, W, H, TR = 30, 500, 10, 20000, 20
kappa, tau_F = 1, 1
rows = []
def summarize(Ts):
    c = [t for t in Ts if t is not None]
    cs = sorted(c)
    return dict(conv=len(c), med=st.median(c) if c else None, maxT=max(c) if c else None,
                q1=cs[len(cs) // 4] if c else None, q3=cs[(3 * len(cs)) // 4] if c else None)
for tau_D in (5, 8, 10, 10.5, 11, 12, 15, 20, 40, math.inf):
    res = {"bridge": [], "periodic": [], "random": [], "none": []}
    bnd = []
    for tr in range(TR):
        rng = random.Random(7000 + tr)
        sch = RoundRobinPath(n, W, rng)
        s0 = initial_states(n, M, rng)
        sig = max(sigma(v) for v in s0)
        bnd.append(bound_regime_A(sig, n, W, kappa, tau_D))
        res["none"].append(run(sch, n, s0, NoAttack(), Budget(kappa, tau_D, tau_F), H)["T_sync"])
        res["bridge"].append(run(sch, n, s0, BridgeBlocker(sch.bridge), Budget(kappa, tau_D, tau_F), H)["T_sync"])
        # periodic single-round blackout, period P = ceil(tau_D) (or W if tau_D = inf: no attack possible)
        if math.isinf(tau_D):
            worst = res["none"][-1]
        else:
            worst = -1
            for P in range(math.ceil(tau_D), math.ceil(tau_D) + W):
                for ph in range(P):
                    T = run(sch, n, s0, PeriodicBlackout(P, 1, ph), Budget(kappa, tau_D, tau_F), H)["T_sync"]
                    if T is None: worst = None; break
                    worst = max(worst, T)
                if worst is None: break
        res["periodic"].append(worst)
        res["random"].append(run(sch, n, s0, RandomBlackout(0.5, random.Random(tr)), Budget(kappa, tau_D, tau_F), H)["T_sync"])
    r = dict(tau_D=tau_D, bound_max=max(bnd) if bnd[0] else None, bound_min=min(bnd) if bnd[0] else None)
    for k, v in res.items():
        r[k] = summarize(v)
    # check bound
    for k in ("bridge", "periodic", "random", "none"):
        if tau_D > W:
            assert all(t is not None and t <= b for t, b in zip(res[k], bnd)), (tau_D, k)
    rows.append(r); print(r)
json.dump(rows, open("e2.json", "w"), indent=1, default=str)
