"""Application: certified phase switching in formation assembly under DoS.
n robots start at random positions and drive to assigned slots of a connected grid formation with
randomly perturbed speeds, so arrival times cannot be predicted at start-up (precomputed flooding does
not apply). Communication: unit-disk graph of the current positions. A robot releases its token when it
arrives (certificate flooding); the team may switch to the next mission phase once certified.
Adversaries: targeted blackout, budget-saving (waits until the last arrival c*), cut-cover (isolates the
last-arriving robot from its arrival). Reports overhead T_sync - c* and the static-formation bound."""
import json, math, random, statistics as st
import numpy as np
from fractions import Fraction as Fr
from scgd_dos import *

class Formation:
    def __init__(self, n, r, rng, H=4000):
        rows, cols = 4, n // 4
        slots = [(0.5 + 0.15 * (c - (cols - 1) / 2), 0.5 + 0.15 * (rr - (rows - 1) / 2))
                 for rr in range(rows) for c in range(cols)]
        rng.shuffle(slots)
        pos = np.array([[rng.random(), rng.random()] for _ in range(n)])
        slot = np.array(slots)
        vnom = np.array([rng.uniform(0.002, 0.01) for _ in range(n)])
        self.arr = [None] * n
        self.E = []
        iu = np.triu_indices(n, 1)
        for t in range(H):
            for i in range(n):
                if self.arr[i] is None and np.linalg.norm(slot[i] - pos[i]) <= 0.005:
                    self.arr[i] = t
            d = np.sqrt(((pos[:, None, :] - pos[None, :, :]) ** 2).sum(-1))
            self.E.append([(int(a), int(b)) for a, b, m in zip(iu[0], iu[1], d[iu] <= r) if m])
            for i in range(n):
                if self.arr[i] is not None:
                    pos[i] = slot[i]; continue
                step = slot[i] - pos[i]; dist = np.linalg.norm(step)
                v = vnom[i] * (1 + 0.5 * rng.uniform(-1, 1))
                pos[i] = slot[i] if dist <= v else pos[i] + step * v / dist

    def intended(self, t):
        return self.E[t]

class Arrival(CertFlood):
    """Certificate flooding where robot i's token is released at its (unpredictable) arrival time."""
    name = "certificate (arrival)"

    def __init__(self, n, arr):
        self.n, self.full, self.arr = n, (1 << n) - 1, arr
        self.K = [0] * n
        self.t = 0

    def step(self, t, E):
        K = self.K; nK = list(K)
        for a, b in E:
            nK[a] |= K[b]; nK[b] |= K[a]
        for i in range(self.n):
            if self.arr[i] is not None and self.arr[i] <= t + 1:
                nK[i] |= 1 << i
        self.K = nK

def q(v):
    v = sorted(v); n = len(v)
    return v[n // 4], st.median(v), v[(3 * n) // 4], v[-1]

n, r, H, TR = 20, 0.25, 4000, 20
scen = {"none": (0, math.inf), "(H) kappa=5, tau_D=1.25": (5, 1.25), "kappa=10, tau_D=1.1": (10, 1.1)}
res = {}
cstars = []
for tr in range(TR):
    rng = random.Random(900 + tr)
    F = Formation(n, r, rng, H)
    assert all(a is not None for a in F.arr)
    cstar = max(F.arr); cstars.append(cstar)
    last = max(range(n), key=lambda i: F.arr[i])
    assert all(connected(n, F.intended(t)) for t in range(cstar, H))
    for sname, (kappa, tD) in scen.items():
        advs = {"none": lambda: ObliviousWrap(NoAttack())} if sname == "none" else {
            "targeted": lambda: TargetedBlackout(0), "budget-saving": lambda: TargetedBlackout(cstar),
            "cut-cover": lambda: CutCover(last, F.arr[last])}
        for aname, mk in advs.items():
            proto = Arrival(n, F.arr)
            T, atk, _ = run_protocol(F, n, proto, mk(), Budget(kappa, tD, 1), H)
            R = res.setdefault((sname, aname), dict(ov=[], frac=[], bnd=[]))
            R["ov"].append(None if T is None else T - cstar)
            R["frac"].append(sum(1 for a in atk if T is None or a < T) / (T or H))
            b = (n - 1) * (math.floor(Fr(kappa) / (1 - 1 / Fr(tD).limit_denominator(10**6))) + 1) if kappa else n - 1
            R["bnd"].append(b)
    print(tr, cstar, flush=True)
out = []
for (sname, aname), R in res.items():
    ov = [x for x in R["ov"] if x is not None]
    row = dict(scenario=sname, adversary=aname, conv=len(ov), trials=len(R["ov"]), overhead_q=q(ov) if ov else None,
               frac_med=st.median(R["frac"]), bound=R["bnd"][0], bound_holds=all(x is not None and x <= b for x, b in zip(R["ov"], R["bnd"])))
    out.append(row); print(row)
print("c* quartiles", q(cstars))
json.dump(dict(rows=out, cstar=q(cstars)), open("e7.json", "w"), indent=1)
